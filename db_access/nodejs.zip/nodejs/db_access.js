module.exports = {
   // credentials to the DB are here. HIDDEN and not exposed outside
   // NOTE: YOU SHOULD REPLACE WITH YOUR OWN NATURALLY. These are the ones
   // that you set up 
   config : {
    "host"     : "rolandserver.c96wkbcrki0i.us-east-1.rds.amazonaws.com",
    "user"     : "admin",
    "password" : "SourApple123",
    "database" : "Seats4u"
  }
}
